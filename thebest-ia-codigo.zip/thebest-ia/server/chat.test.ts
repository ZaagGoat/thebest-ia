import { describe, expect, it, beforeEach, vi } from "vitest";
import { appRouter } from "./routers";
import type { TrpcContext } from "./_core/context";

type AuthenticatedUser = NonNullable<TrpcContext["user"]>;

function createAuthContext(): { ctx: TrpcContext } {
  const user: AuthenticatedUser = {
    id: 1,
    openId: "test-user",
    email: "test@example.com",
    name: "Test User",
    loginMethod: "manus",
    role: "user",
    createdAt: new Date(),
    updatedAt: new Date(),
    lastSignedIn: new Date(),
  };

  const ctx: TrpcContext = {
    user,
    req: {
      protocol: "https",
      headers: {},
    } as TrpcContext["req"],
    res: {} as TrpcContext["res"],
  };

  return { ctx };
}

describe("chat router", () => {
  let ctx: TrpcContext;

  beforeEach(() => {
    const authCtx = createAuthContext();
    ctx = authCtx.ctx;
  });

  it("should create a new conversation", async () => {
    const caller = appRouter.createCaller(ctx);

    const result = await caller.chat.createConversation({
      title: "Test Conversation",
    });

    expect(result).toBeDefined();
    expect(result.id).toBeDefined();
    expect(result.title).toBe("Test Conversation");
    expect(result.userId).toBe(ctx.user!.id);
  });

  it("should list conversations for authenticated user", async () => {
    const caller = appRouter.createCaller(ctx);

    // Create a conversation first
    await caller.chat.createConversation({
      title: "Test Conv 1",
    });

    const conversations = await caller.chat.listConversations();

    expect(Array.isArray(conversations)).toBe(true);
    expect(conversations.length).toBeGreaterThan(0);
  });

  it("should get a conversation with messages", async () => {
    const caller = appRouter.createCaller(ctx);

    // Create a conversation
    const newConv = await caller.chat.createConversation({
      title: "Test Conv",
    });

    // Get the conversation
    const result = await caller.chat.getConversation({
      conversationId: newConv.id,
    });

    expect(result).toBeDefined();
    expect(result?.conversation.id).toBe(newConv.id);
    expect(Array.isArray(result?.messages)).toBe(true);
  });

  it("should prevent access to other users' conversations", async () => {
    const caller = appRouter.createCaller(ctx);

    // Create a conversation
    const newConv = await caller.chat.createConversation({
      title: "Test Conv",
    });

    // Create a different user context
    const otherUser: AuthenticatedUser = {
      id: 2,
      openId: "other-user",
      email: "other@example.com",
      name: "Other User",
      loginMethod: "manus",
      role: "user",
      createdAt: new Date(),
      updatedAt: new Date(),
      lastSignedIn: new Date(),
    };

    const otherCtx: TrpcContext = {
      user: otherUser,
      req: { protocol: "https", headers: {} } as TrpcContext["req"],
      res: {} as TrpcContext["res"],
    };

    const otherCaller = appRouter.createCaller(otherCtx);

    // Try to access the conversation as another user
    const result = await otherCaller.chat.getConversation({
      conversationId: newConv.id,
    });

    expect(result).toBeNull();
  });

  it("should delete a conversation", async () => {
    const caller = appRouter.createCaller(ctx);

    // Create a conversation
    const newConv = await caller.chat.createConversation({
      title: "Test Conv",
    });

    // Delete it
    const deleteResult = await caller.chat.deleteConversation({
      conversationId: newConv.id,
    });

    expect(deleteResult.success).toBe(true);

    // Try to get it - should be null
    const result = await caller.chat.getConversation({
      conversationId: newConv.id,
    });

    expect(result).toBeNull();
  });

  it("should update conversation title", async () => {
    const caller = appRouter.createCaller(ctx);

    // Create a conversation
    const newConv = await caller.chat.createConversation({
      title: "Original Title",
    });

    // Update the title
    const updateResult = await caller.chat.updateConversationTitle({
      conversationId: newConv.id,
      title: "Updated Title",
    });

    expect(updateResult.success).toBe(true);

    // Verify the title was updated
    const result = await caller.chat.getConversation({
      conversationId: newConv.id,
    });

    expect(result?.conversation.title).toBe("Updated Title");
  });

  it("should prevent unauthorized deletion", async () => {
    const caller = appRouter.createCaller(ctx);

    // Create a conversation
    const newConv = await caller.chat.createConversation({
      title: "Test Conv",
    });

    // Create a different user context
    const otherUser: AuthenticatedUser = {
      id: 2,
      openId: "other-user",
      email: "other@example.com",
      name: "Other User",
      loginMethod: "manus",
      role: "user",
      createdAt: new Date(),
      updatedAt: new Date(),
      lastSignedIn: new Date(),
    };

    const otherCtx: TrpcContext = {
      user: otherUser,
      req: { protocol: "https", headers: {} } as TrpcContext["req"],
      res: {} as TrpcContext["res"],
    };

    const otherCaller = appRouter.createCaller(otherCtx);

    // Try to delete as another user - should throw error
    try {
      await otherCaller.chat.deleteConversation({
        conversationId: newConv.id,
      });
      expect.fail("Should have thrown an error");
    } catch (error) {
      expect(error).toBeDefined();
    }
  });
});
