/**
 * Gerenciador de modo de atualização de banco de dados
 * Permite ao usuário atualizar o conhecimento da IA
 */

const updateModeUsers = new Map<number, boolean>();

/**
 * Verificar se o usuário está em modo de atualização
 */
export function isUserInUpdateMode(userId: number): boolean {
  return updateModeUsers.get(userId) ?? false;
}

/**
 * Ativar modo de atualização para um usuário
 */
export function activateUpdateMode(userId: number): void {
  updateModeUsers.set(userId, true);
}

/**
 * Desativar modo de atualização para um usuário
 */
export function deactivateUpdateMode(userId: number): void {
  updateModeUsers.set(userId, false);
}

/**
 * Verificar se a mensagem é o comando de atualização e extrair o conhecimento
 */
export function isUpdateCommand(message: string): boolean {
  const updateKeywords = [
    "irei atualizar o seu banco de dados:",
    "irei atualizar seu banco de dados:",
    "vou atualizar o seu banco de dados:",
    "vou atualizar seu banco de dados:",
  ];

  const lowerMessage = message.toLowerCase().trim();
  return updateKeywords.some((keyword) => lowerMessage.includes(keyword));
}

/**
 * Extrair o conhecimento da mensagem de atualização
 */
export function extractKnowledgeFromUpdateCommand(message: string): string {
  const updateKeywords = [
    "irei atualizar o seu banco de dados:",
    "irei atualizar seu banco de dados:",
    "vou atualizar o seu banco de dados:",
    "vou atualizar seu banco de dados:",
  ];

  const lowerMessage = message.toLowerCase().trim();
  
  for (const keyword of updateKeywords) {
    if (lowerMessage.includes(keyword)) {
      // Find the index where the keyword ends
      const keywordIndex = lowerMessage.indexOf(keyword);
      const contentStart = keywordIndex + keyword.length;
      // Extract everything after the colon and trim
      const knowledge = message.substring(contentStart).trim();
      return knowledge;
    }
  }

  return "";
}

/**
 * Gerar resposta de aceitação de atualização com o conhecimento armazenado
 */
export function getUpdateModeAcceptanceResponse(knowledge: string): string {
  return `✅ **Informação Armazenada com Sucesso!**\n\n**Conhecimento Salvo:** "${knowledge}"\n\nEsta informação foi permanentemente armazenada no meu banco de dados e será usada em todas as minhas respostas futuras.`;
}

/**
 * Verificar se a mensagem é o comando de conclusão
 */
export function isCompleteUpdateCommand(message: string): boolean {
  const completeKeywords = [
    "concluir atualização",
    "finalizar atualização",
    "sair do modo de atualização",
    "parar atualização",
    "terminar atualização",
  ];

  const lowerMessage = message.toLowerCase().trim();
  return completeKeywords.some((keyword) => lowerMessage.includes(keyword));
}

/**
 * Gerar resposta de conclusão de atualização
 */
export function getUpdateModeCompleteResponse(): string {
  return "✅ **Modo de Atualização Desativado!**\n\nObrigado por atualizar meu conhecimento! Todas as informações que você forneceu foram armazenadas com sucesso. Agora posso usar esse novo conhecimento em futuras conversas.";
}

/**
 * Gerar resposta de armazenamento de conhecimento
 */
export function getKnowledgeStoredResponse(): string {
  return "✅ Informação armazenada com sucesso no meu banco de dados!";
}
