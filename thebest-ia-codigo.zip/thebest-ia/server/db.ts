import { asc, desc, eq } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import { InsertUser, users, conversations, messages, customKnowledge, InsertCustomKnowledge, generatedImages } from "../drizzle/schema";
import { ENV } from './_core/env';

let _db: ReturnType<typeof drizzle> | null = null;

// Lazily create the drizzle instance so local tooling can run without a DB.
export async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try {
      _db = drizzle(process.env.DATABASE_URL);
    } catch (error) {
      console.warn("[Database] Failed to connect:", error);
      _db = null;
    }
  }
  return _db;
}

export async function upsertUser(user: InsertUser): Promise<void> {
  if (!user.openId) {
    throw new Error("User openId is required for upsert");
  }

  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot upsert user: database not available");
    return;
  }

  try {
    const values: InsertUser = {
      openId: user.openId,
    };
    const updateSet: Record<string, unknown> = {};

    const textFields = ["name", "email", "loginMethod"] as const;
    type TextField = (typeof textFields)[number];

    const assignNullable = (field: TextField) => {
      const value = user[field];
      if (value === undefined) return;
      const normalized = value ?? null;
      values[field] = normalized;
      updateSet[field] = normalized;
    };

    textFields.forEach(assignNullable);

    if (user.lastSignedIn !== undefined) {
      values.lastSignedIn = user.lastSignedIn;
      updateSet.lastSignedIn = user.lastSignedIn;
    }
    if (user.role !== undefined) {
      values.role = user.role;
      updateSet.role = user.role;
    } else if (user.openId === ENV.ownerOpenId) {
      values.role = 'admin';
      updateSet.role = 'admin';
    }

    if (!values.lastSignedIn) {
      values.lastSignedIn = new Date();
    }

    if (Object.keys(updateSet).length === 0) {
      updateSet.lastSignedIn = new Date();
    }

    await db.insert(users).values(values).onDuplicateKeyUpdate({
      set: updateSet,
    });
  } catch (error) {
    console.error("[Database] Failed to upsert user:", error);
    throw error;
  }
}

export async function getUserByOpenId(openId: string) {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get user: database not available");
    return undefined;
  }

  const result = await db.select().from(users).where(eq(users.openId, openId)).limit(1);

  return result.length > 0 ? result[0] : undefined;
}

/**
 * Get all conversations for a user, ordered by most recent
 */
export async function getUserConversations(userId: number) {
  const db = await getDb();
  if (!db) return [];

  return db
    .select()
    .from(conversations)
    .where(eq(conversations.userId, userId))
    .orderBy(desc(conversations.updatedAt));
}

/**
 * Get a specific conversation with all its messages
 */
export async function getConversationWithMessages(conversationId: number, userId: number) {
  const db = await getDb();
  if (!db) return null;

  const conversation = await db
    .select()
    .from(conversations)
    .where(eq(conversations.id, conversationId))
    .limit(1);

  if (!conversation.length || conversation[0].userId !== userId) {
    return null; // Unauthorized
  }

  const msgs = await db
    .select()
    .from(messages)
    .where(eq(messages.conversationId, conversationId))
    .orderBy(asc(messages.createdAt));

  return {
    conversation: conversation[0],
    messages: msgs,
  };
}

/**
 * Create a new conversation
 */
export async function createConversation(userId: number, title: string = "Nova Conversa") {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  const result = await db.insert(conversations).values({
    userId,
    title,
  });

  const id = result[0].insertId as number;
  return { id, userId, title, createdAt: new Date(), updatedAt: new Date() };
}

/**
 * Add a message to a conversation
 */
export async function addMessage(
  conversationId: number,
  role: "user" | "assistant",
  content: string
) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  await db.insert(messages).values({
    conversationId,
    role,
    content,
  });
}

/**
 * Delete a conversation and its messages
 */
export async function deleteConversation(conversationId: number, userId: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  // Verify ownership
  const conv = await db
    .select()
    .from(conversations)
    .where(eq(conversations.id, conversationId))
    .limit(1);

  if (!conv.length || conv[0].userId !== userId) {
    throw new Error("Unauthorized");
  }

  // Delete messages first
  await db.delete(messages).where(eq(messages.conversationId, conversationId));

  // Delete conversation
  await db.delete(conversations).where(eq(conversations.id, conversationId));
}

/**
 * Update conversation title
 */
export async function updateConversationTitle(conversationId: number, userId: number, title: string) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  // Verify ownership
  const conv = await db
    .select()
    .from(conversations)
    .where(eq(conversations.id, conversationId))
    .limit(1);

  if (!conv.length || conv[0].userId !== userId) {
    throw new Error("Unauthorized");
  }

  await db
    .update(conversations)
    .set({ title, updatedAt: new Date() })
    .where(eq(conversations.id, conversationId));
}


// Custom Knowledge functions

export async function addCustomKnowledge(
  userId: number,
  content: string,
  category: string = "general"
): Promise<void> {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot add custom knowledge: database not available");
    return;
  }

  try {
    await db.insert(customKnowledge).values({
      userId,
      content,
      category,
    });
  } catch (error) {
    console.error("[Database] Failed to add custom knowledge:", error);
    throw error;
  }
}

export async function getUserCustomKnowledge(userId: number): Promise<string> {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get custom knowledge: database not available");
    return "";
  }

  try {
    const results = await db
      .select()
      .from(customKnowledge)
      .where(eq(customKnowledge.userId, userId))
      .orderBy(desc(customKnowledge.createdAt));

    if (results.length === 0) {
      return "";
    }

    // Consolidate all custom knowledge into a single string
    const knowledgeItems = results
      .map((item) => `- ${item.content}`)
      .join("\n");

    return `\n\nConhecimento Customizado do Usuário:\n${knowledgeItems}`;
  } catch (error) {
    console.error("[Database] Failed to get custom knowledge:", error);
    return "";
  }
}

export async function deleteAllCustomKnowledge(userId: number): Promise<void> {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot delete custom knowledge: database not available");
    return;
  }

  try {
    await db
      .delete(customKnowledge)
      .where(eq(customKnowledge.userId, userId));
  } catch (error) {
    console.error("[Database] Failed to delete custom knowledge:", error);
    throw error;
  }
}


// Generated Images functions

export async function saveGeneratedImage(
  userId: number,
  prompt: string,
  imageUrl: string,
  conversationId?: number
): Promise<void> {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot save generated image: database not available");
    return;
  }

  try {
    await db.insert(generatedImages).values({
      userId,
      prompt,
      imageUrl,
      conversationId,
    });
  } catch (error) {
    console.error("[Database] Failed to save generated image:", error);
    throw error;
  }
}

export async function getUserGeneratedImages(userId: number) {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get generated images: database not available");
    return [];
  }

  try {
    const results = await db
      .select()
      .from(generatedImages)
      .where(eq(generatedImages.userId, userId))
      .orderBy(desc(generatedImages.createdAt));

    return results;
  } catch (error) {
    console.error("[Database] Failed to get generated images:", error);
    return [];
  }
}

export async function deleteGeneratedImage(
  imageId: number,
  userId: number
): Promise<void> {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot delete generated image: database not available");
    return;
  }

  try {
    const image = await db
      .select()
      .from(generatedImages)
      .where(eq(generatedImages.id, imageId))
      .limit(1);

    if (!image.length || image[0].userId !== userId) {
      throw new Error("Unauthorized");
    }

    await db
      .delete(generatedImages)
      .where(eq(generatedImages.id, imageId));
  } catch (error) {
    console.error("[Database] Failed to delete generated image:", error);
    throw error;
  }
}
