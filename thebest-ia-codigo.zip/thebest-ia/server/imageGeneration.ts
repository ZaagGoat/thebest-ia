import { generateImage } from "./_core/imageGeneration";

export interface GeneratedImage {
  url: string;
  prompt: string;
  createdAt: Date;
}

/**
 * Gera uma imagem baseada no prompt fornecido
 */
export async function generateImageFromPrompt(
  prompt: string
): Promise<GeneratedImage> {
  try {
    console.log("[Image Generation] Generating image for prompt:", prompt);

    const result = await generateImage({
      prompt,
    });

    if (!result.url) {
      throw new Error("Failed to generate image: no URL returned");
    }

    console.log("[Image Generation] Image generated successfully:", result.url);

    return {
      url: result.url,
      prompt,
      createdAt: new Date(),
    };
  } catch (error) {
    console.error("[Image Generation] Error generating image:", error);
    throw error;
  }
}

/**
 * Edita uma imagem existente baseado em um prompt
 */
export async function editImageFromPrompt(
  prompt: string,
  imageUrl: string,
  mimeType: string = "image/jpeg"
): Promise<GeneratedImage> {
  try {
    console.log("[Image Generation] Editing image with prompt:", prompt);

    const result = await generateImage({
      prompt,
      originalImages: [
        {
          url: imageUrl,
          mimeType,
        },
      ],
    });

    if (!result.url) {
      throw new Error("Failed to edit image: no URL returned");
    }

    console.log("[Image Generation] Image edited successfully:", result.url);

    return {
      url: result.url,
      prompt,
      createdAt: new Date(),
    };
  } catch (error) {
    console.error("[Image Generation] Error editing image:", error);
    throw error;
  }
}

/**
 * Detecta se uma mensagem é um comando de geração de imagem
 */
export function isImageGenerationCommand(message: string): boolean {
  const imageCommands = [
    "gerar imagem",
    "criar imagem",
    "desenha",
    "desenhe",
    "crie uma imagem",
    "gere uma imagem",
    "editar imagem",
    "edite a imagem",
    "modifique a imagem",
    "generate image",
    "create image",
    "draw",
  ];

  const lowerMessage = message.toLowerCase();
  return imageCommands.some((cmd) => lowerMessage.includes(cmd));
}

/**
 * Extrai o prompt de geração de imagem da mensagem
 */
export function extractImagePrompt(message: string): string {
  // Remove comandos comuns
  let prompt = message
    .replace(/gerar imagem[:\s]*/i, "")
    .replace(/criar imagem[:\s]*/i, "")
    .replace(/desenha[:\s]*/i, "")
    .replace(/desenhe[:\s]*/i, "")
    .replace(/crie uma imagem[:\s]*/i, "")
    .replace(/gere uma imagem[:\s]*/i, "")
    .replace(/editar imagem[:\s]*/i, "")
    .replace(/edite a imagem[:\s]*/i, "")
    .replace(/modifique a imagem[:\s]*/i, "")
    .replace(/generate image[:\s]*/i, "")
    .replace(/create image[:\s]*/i, "")
    .replace(/draw[:\s]*/i, "")
    .trim();

  return prompt || "Uma imagem bonita e criativa";
}
