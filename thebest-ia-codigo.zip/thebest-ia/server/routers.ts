import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { publicProcedure, protectedProcedure, router } from "./_core/trpc";

export const appRouter = router({
    // if you need to use socket.io, read and register route in server/_core/index.ts, all api should start with '/api/' so that the gateway can route correctly
  system: systemRouter,
  auth: router({
    me: publicProcedure.query(opts => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return {
        success: true,
      } as const;
    }),
  }),

  chat: router({
    // Get all conversations for the current user
    listConversations: protectedProcedure.query(async ({ ctx }) => {
      const { getUserConversations } = await import("./db");
      return getUserConversations(ctx.user.id);
    }),

    // Get a specific conversation with all messages
    getConversation: protectedProcedure
      .input((val: unknown) => {
        if (typeof val === "object" && val !== null && "conversationId" in val) {
          return { conversationId: (val as any).conversationId };
        }
        throw new Error("Invalid input");
      })
      .query(async ({ ctx, input }) => {
        const { getConversationWithMessages } = await import("./db");
        return getConversationWithMessages(input.conversationId, ctx.user.id);
      }),

    // Create a new conversation
    createConversation: protectedProcedure
      .input((val: unknown) => {
        if (typeof val === "object" && val !== null && "title" in val) {
          return { title: (val as any).title || "Nova Conversa" };
        }
        return { title: "Nova Conversa" };
      })
      .mutation(async ({ ctx, input }) => {
        const { createConversation } = await import("./db");
        return createConversation(ctx.user.id, input.title);
      }),

    // Send a message and get AI response
    sendMessage: protectedProcedure
      .input((val: unknown) => {
        if (
          typeof val === "object" &&
          val !== null &&
          "conversationId" in val &&
          "message" in val
        ) {
          return {
            conversationId: (val as any).conversationId,
            message: (val as any).message,
          };
        }
        throw new Error("Invalid input");
      })
      .mutation(async ({ ctx, input }) => {
        const { getConversationWithMessages, addMessage, addCustomKnowledge, getUserCustomKnowledge } = await import("./db");
        const { invokeLLM } = await import("./_core/llm");
        const { searchMultipleSources, formatMultiSourceResults, isCreatorQuestion, getCreatorResponse } = await import("./search");
        const { isUserInUpdateMode, activateUpdateMode, deactivateUpdateMode, isUpdateCommand, isCompleteUpdateCommand, extractKnowledgeFromUpdateCommand, getUpdateModeAcceptanceResponse, getUpdateModeCompleteResponse, getKnowledgeStoredResponse } = await import("./updateMode");

        // Verify conversation ownership
        const conv = await getConversationWithMessages(input.conversationId, ctx.user.id);
        if (!conv) {
          throw new Error("Conversation not found");
        }

        // Add user message
        await addMessage(input.conversationId, "user", input.message);

        // Check if user is activating update mode with knowledge
        if (isUpdateCommand(input.message)) {
          const knowledge = extractKnowledgeFromUpdateCommand(input.message);
          if (knowledge) {
            // Store the knowledge immediately
            await addCustomKnowledge(ctx.user.id, knowledge, "direct_update");
            const response = getUpdateModeAcceptanceResponse(knowledge);
            await addMessage(input.conversationId, "assistant", response);
            return {
              userMessage: input.message,
              assistantMessage: response,
            };
          }
        }

        // Check if user is in update mode
        if (isUserInUpdateMode(ctx.user.id)) {
          // Check if user wants to complete update mode
          if (isCompleteUpdateCommand(input.message)) {
            deactivateUpdateMode(ctx.user.id);
            const response = getUpdateModeCompleteResponse();
            await addMessage(input.conversationId, "assistant", response);
            return {
              userMessage: input.message,
              assistantMessage: response,
            };
          }

          // Store the knowledge
          await addCustomKnowledge(ctx.user.id, input.message, "user_provided");
          const response = getKnowledgeStoredResponse();
          await addMessage(input.conversationId, "assistant", response);
          return {
            userMessage: input.message,
            assistantMessage: response,
          };
        }

        // Check if question is about the creator
        if (isCreatorQuestion(input.message)) {
          const creatorResponse = getCreatorResponse();
          await addMessage(input.conversationId, "assistant", creatorResponse);
          return {
            userMessage: input.message,
            assistantMessage: creatorResponse,
          };
        }

        // Search multiple sources for current information
        const multiSourceResults = await searchMultipleSources(input.message);
        const searchContext = await formatMultiSourceResults(multiSourceResults);

        // Get user's custom knowledge
        const customKnowledgeContext = await getUserCustomKnowledge(ctx.user.id);

        // Prepare messages for LLM
        const llmMessages = [
          {
            role: "system" as const,
            content:
              "Você é um assistente inteligente e útil em 2026, criado por Daniel, alimentado por GPT-5. Seu conhecimento é atualizado até dezembro de 2026. Responda de forma clara, concisa e amigável. Use markdown quando apropriado. Utilize as informações consolidadas de múltiplas fontes (Google, GPT-5, Manus) fornecidas para garantir respostas sempre atualizadas e precisas com os dados mais recentes de 2026.",
          },
          ...conv.messages.map((msg) => ({
            role: msg.role as "user" | "assistant",
            content: msg.content,
          })),
          {
            role: "user" as const,
            content: input.message + searchContext + customKnowledgeContext,
          },
        ];

        // Get AI response
        const response = await invokeLLM({
          messages: llmMessages,
        });

        const assistantContent = response.choices[0]?.message?.content;
        const assistantMessage = typeof assistantContent === "string" ? assistantContent : "Desculpe, não consegui processar sua mensagem.";

        // Add assistant message
        await addMessage(input.conversationId, "assistant", assistantMessage);

        return {
          userMessage: input.message,
          assistantMessage,
        };
      }),

    // Delete a conversation
    deleteConversation: protectedProcedure
      .input((val: unknown) => {
        if (typeof val === "object" && val !== null && "conversationId" in val) {
          return { conversationId: (val as any).conversationId };
        }
        throw new Error("Invalid input");
      })
      .mutation(async ({ ctx, input }) => {
        const { deleteConversation } = await import("./db");
        await deleteConversation(input.conversationId, ctx.user.id);
        return { success: true };
      }),

    // Generate image
    generateImage: protectedProcedure
      .input((val: unknown) => {
        if (typeof val === "object" && val !== null && "prompt" in val) {
          return { prompt: (val as any).prompt, conversationId: (val as any).conversationId };
        }
        throw new Error("Invalid input");
      })
      .mutation(async ({ ctx, input }) => {
        const { generateImageFromPrompt } = await import("./imageGeneration");
        const { saveGeneratedImage } = await import("./db");
        try {
          const result = await generateImageFromPrompt(input.prompt);
          await saveGeneratedImage(ctx.user.id, input.prompt, result.url, input.conversationId);
          return {
            success: true,
            imageUrl: result.url,
            prompt: result.prompt,
          };
        } catch (error) {
          console.error("Image generation failed:", error);
          return {
            success: false,
            error: "Falha ao gerar imagem. Tente novamente.",
          };
        }
      }),

    // Get user's generated images
    getGeneratedImages: protectedProcedure.query(async ({ ctx }) => {
      const { getUserGeneratedImages } = await import("./db");
      return getUserGeneratedImages(ctx.user.id);
    }),

    // Delete generated image
    deleteGeneratedImage: protectedProcedure
      .input((val: unknown) => {
        if (typeof val === "object" && val !== null && "imageId" in val) {
          return { imageId: (val as any).imageId };
        }
        throw new Error("Invalid input");
      })
      .mutation(async ({ ctx, input }) => {
        const { deleteGeneratedImage } = await import("./db");
        await deleteGeneratedImage(input.imageId, ctx.user.id);
        return { success: true };
      }),

    // Update conversation title
    updateConversationTitle: protectedProcedure
      .input((val: unknown) => {
        if (
          typeof val === "object" &&
          val !== null &&
          "conversationId" in val &&
          "title" in val
        ) {
          return {
            conversationId: (val as any).conversationId,
            title: (val as any).title,
          };
        }
        throw new Error("Invalid input");
      })
      .mutation(async ({ ctx, input }) => {
        const { updateConversationTitle } = await import("./db");
        await updateConversationTitle(input.conversationId, ctx.user.id, input.title);
        return { success: true };
      }),
  }),
});

export type AppRouter = typeof appRouter;
