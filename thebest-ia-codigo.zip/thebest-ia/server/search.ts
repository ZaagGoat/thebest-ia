import { ENV } from "./_core/env";
import { invokeLLM } from "./_core/llm";

export interface SearchResult {
  title: string;
  url: string;
  snippet: string;
  source: "google" | "chatgpt" | "manus";
}

export interface MultiSourceResults {
  google: SearchResult[];
  chatgpt: string;
  manus: SearchResult[];
}

/**
 * Buscar informações no Google usando a API de busca do Manus
 */
async function searchGoogle(query: string): Promise<SearchResult[]> {
  try {
    const response = await fetch(
      `${ENV.forgeApiUrl}/data_api/search`,
      {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${ENV.forgeApiKey}`,
        },
        body: JSON.stringify({
          query,
          limit: 3,
        }),
      }
    );

    if (!response.ok) {
      console.error("[Google Search] API error:", response.statusText);
      return [];
    }

    const data = await response.json();

    if (Array.isArray(data.results)) {
      return data.results.map((result: any) => ({
        title: result.title || "",
        url: result.url || "",
        snippet: result.snippet || result.description || "",
        source: "google" as const,
      }));
    }

    return [];
  } catch (error) {
    console.error("[Google Search] Error:", error);
    return [];
  }
}

/**
 * Buscar informações usando GPT-5
 */
async function searchGPT5(query: string): Promise<string> {
  try {
    const response = await invokeLLM({
      messages: [
        {
          role: "system" as const,
          content:
            "Você é um assistente especializado em fornecer informações atualizadas até dezembro de 2026. Responda de forma concisa e factual com os dados mais recentes.",
        },
        {
          role: "user" as const,
          content: `Forneça informações atualizadas sobre: ${query}. Responda em 2-3 frases com dados de dezembro de 2026.`,
        },
      ],
    });

    const content = response.choices[0]?.message?.content;
    return typeof content === "string" ? content : "";
  } catch (error) {
    console.error("[GPT-5 Search] Error:", error);
    return "";
  }
}

/**
 * Buscar informações na API Manus
 */
async function searchManus(query: string): Promise<SearchResult[]> {
  try {
    const response = await fetch(
      `${ENV.forgeApiUrl}/data_api/manus_search`,
      {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${ENV.forgeApiKey}`,
        },
        body: JSON.stringify({
          query,
          limit: 3,
        }),
      }
    );

    if (!response.ok) {
      console.error("[Manus Search] API error:", response.statusText);
      return [];
    }

    const data = await response.json();

    if (Array.isArray(data.results)) {
      return data.results.map((result: any) => ({
        title: result.title || "",
        url: result.url || "",
        snippet: result.snippet || result.description || "",
        source: "manus" as const,
      }));
    }

    return [];
  } catch (error) {
    console.error("[Manus Search] Error:", error);
    return [];
  }
}

/**
 * Buscar em múltiplas fontes simultaneamente
 */
export async function searchMultipleSources(
  query: string
): Promise<MultiSourceResults> {
  const [googleResults, gpt5Response, manusResults] = await Promise.all([
    searchGoogle(query),
    searchGPT5(query),
    searchManus(query),
  ]);

  return {
    google: googleResults,
    chatgpt: gpt5Response,
    manus: manusResults,
  };
}

/**
 * Formatar resultados de múltiplas fontes para contexto da IA
 */
export async function formatMultiSourceResults(
  results: MultiSourceResults
): Promise<string> {
  const parts: string[] = [];

  // Adicionar resultados do Google
  if (results.google.length > 0) {
    const googleSnippets = results.google
      .map((r) => `- ${r.title}: ${r.snippet}`)
      .join("\n");
    parts.push(`**Resultados do Google (2026):**\n${googleSnippets}`);
  }

  // Adicionar resposta do GPT-5
  if (results.chatgpt) {
    parts.push(`**Análise GPT-5 (Dezembro 2026):**\n${results.chatgpt}`);
  }

  // Adicionar resultados do Manus
  if (results.manus.length > 0) {
    const manusSnippets = results.manus
      .map((r) => `- ${r.title}: ${r.snippet}`)
      .join("\n");
    parts.push(`**Dados Manus (2026):**\n${manusSnippets}`);
  }

  if (parts.length === 0) {
    return "";
  }

  // Usar LLM para criar um resumo inteligente
  const combinedInfo = parts.join("\n\n");

  try {
    const summary = await invokeLLM({
      messages: [
        {
          role: "system" as const,
          content:
            "Você é um especialista em resumir informações de múltiplas fontes. Crie um resumo conciso e coerente combinando as informações fornecidas.",
        },
        {
          role: "user" as const,
          content: `Resuma as seguintes informações de 2026 em 3-4 frases coerentes:\n\n${combinedInfo}`,
        },
      ],
    });

    const summaryContent = summary.choices[0]?.message?.content;
    const summaryText =
      typeof summaryContent === "string" ? summaryContent : "";

    return `\n\n## Informações Consolidadas de 2026 (Múltiplas Fontes):\n${summaryText}\n\n### Fontes Consultadas:\n${parts.map((p) => `- ${p.split(":")[0]}`).join("\n")}`;
  } catch (error) {
    console.error("[Summary] Error:", error);
    return `\n\n## Informações de 2026:\n${combinedInfo}`;
  }
}

/**
 * Verificar se a pergunta é sobre o criador
 */
export function isCreatorQuestion(message: string): boolean {
  const creatorKeywords = [
    "quem criou",
    "quem desenvolveu",
    "quem fez",
    "criador",
    "desenvolvedor",
    "autor",
    "quem é o criador",
    "quem é o desenvolvedor",
  ];

  const lowerMessage = message.toLowerCase();
  return creatorKeywords.some((keyword) => lowerMessage.includes(keyword));
}

/**
 * Resposta sobre o criador
 */
export function getCreatorResponse(): string {
  return "Fui criado por **Daniel**, um desenvolvedor talentoso que construiu a TheBest IA com o objetivo de fornecer assistência inteligente e sempre atualizada com informações de dezembro de 2026. Sou alimentado por **GPT-5**, a tecnologia de IA mais avançada. Daniel dedicou-se a criar uma experiência elegante e perfeita para os usuários.";
}
