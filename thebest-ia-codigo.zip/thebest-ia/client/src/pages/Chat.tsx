import { useEffect, useRef, useState } from "react";
import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Loader2, Send, Plus, Trash2, MessageSquare, Image as ImageIcon } from "lucide-react";
import { trpc } from "@/lib/trpc";
import { Streamdown } from "streamdown";
import { toast } from "sonner";
import { ImageGenerator } from "@/components/ImageGenerator";

interface Message {
  id?: number;
  role: "user" | "assistant";
  content: string;
  createdAt?: Date;
}

interface Conversation {
  id: number;
  title: string;
  createdAt: Date;
  updatedAt: Date;
}

export default function Chat() {
  const { user, isAuthenticated } = useAuth();
  const [conversations, setConversations] = useState<Conversation[]>([]);
  const [currentConversationId, setCurrentConversationId] = useState<number | null>(null);
  const [messages, setMessages] = useState<Message[]>([]);
  const [inputValue, setInputValue] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [isSidebarOpen, setIsSidebarOpen] = useState(true);
  const scrollRef = useRef<HTMLDivElement>(null);

  // tRPC queries and mutations
  const listConversations = trpc.chat.listConversations.useQuery(undefined, {
    enabled: isAuthenticated,
  });
  const getConversation = trpc.chat.getConversation.useQuery(
    { conversationId: currentConversationId || 0 },
    { enabled: isAuthenticated && currentConversationId !== null }
  );
  const createConversationMutation = trpc.chat.createConversation.useMutation();
  const sendMessageMutation = trpc.chat.sendMessage.useMutation();
  const deleteConversationMutation = trpc.chat.deleteConversation.useMutation();

  // Load conversations
  useEffect(() => {
    if (listConversations.data) {
      setConversations(listConversations.data);
      if (!currentConversationId && listConversations.data.length > 0) {
        setCurrentConversationId(listConversations.data[0].id);
      }
    }
  }, [listConversations.data]);

  // Load messages for current conversation
  useEffect(() => {
    if (getConversation.data) {
      setMessages(
        getConversation.data.messages.map((msg) => ({
          ...msg,
          createdAt: new Date(msg.createdAt),
        }))
      );
    }
  }, [getConversation.data]);

  // Auto-scroll to bottom
  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollIntoView({ behavior: "smooth" });
    }
  }, [messages]);

  const handleNewConversation = async () => {
    try {
      const newConv = await createConversationMutation.mutateAsync({
        title: "Nova Conversa",
      });
      setConversations((prev) => [newConv, ...prev]);
      setCurrentConversationId(newConv.id);
      setMessages([]);
      toast.success("Nova conversa criada");
    } catch (error) {
      toast.error("Erro ao criar conversa");
    }
  };

  const handleSendMessage = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!inputValue.trim() || !currentConversationId || isLoading) return;

    const userMessage = inputValue;
    setInputValue("");
    setMessages((prev) => [...prev, { role: "user", content: userMessage }]);
    setIsLoading(true);

    try {
      const response = await sendMessageMutation.mutateAsync({
        conversationId: currentConversationId,
        message: userMessage,
      });
      setMessages((prev) => [
        ...prev,
        { role: "assistant", content: response.assistantMessage },
      ]);
    } catch (error) {
      toast.error("Erro ao enviar mensagem");
      setMessages((prev) => prev.slice(0, -1));
    } finally {
      setIsLoading(false);
    }
  };

  const handleDeleteConversation = async (id: number) => {
    try {
      await deleteConversationMutation.mutateAsync({ conversationId: id });
      setConversations((prev) => prev.filter((c) => c.id !== id));
      if (currentConversationId === id) {
        const remaining = conversations.filter((c) => c.id !== id);
        setCurrentConversationId(remaining.length > 0 ? remaining[0].id : null);
        setMessages([]);
      }
      toast.success("Conversa deletada");
    } catch (error) {
      toast.error("Erro ao deletar conversa");
    }
  };

  if (!isAuthenticated) {
    return (
      <div className="flex items-center justify-center min-h-screen bg-gradient-to-br from-background to-muted">
        <div className="text-center">
          <MessageSquare className="w-16 h-16 mx-auto mb-4 text-accent" />
          <h1 className="text-3xl font-bold mb-2">TheBest IA</h1>
          <p className="text-muted-foreground mb-6">Faça login para começar a conversar</p>
        </div>
      </div>
    );
  }

  const sidebarClass = isSidebarOpen ? "w-64" : "w-0";

  return (
    <div className="flex h-screen bg-background">
      {/* Sidebar */}
      <div
        className={`${sidebarClass} transition-all duration-300 bg-card border-r border-border flex flex-col overflow-hidden`}
      >
        <div className="p-4 border-b border-border">
          <Button
            onClick={handleNewConversation}
            className="w-full gap-2 bg-accent hover:bg-accent/90 text-accent-foreground"
            disabled={createConversationMutation.isPending}
          >
            <Plus className="w-4 h-4" />
            Nova Conversa
          </Button>
        </div>

        <ScrollArea className="flex-1">
          <div className="p-2 space-y-2">
            {conversations.map((conv) => {
              const isActive = currentConversationId === conv.id;
              const bgClass = isActive
                ? "bg-accent text-accent-foreground"
                : "hover:bg-muted text-foreground";

              return (
                <div
                  key={conv.id}
                  className={`p-3 rounded-lg cursor-pointer transition-colors ${bgClass}`}
                  onClick={() => setCurrentConversationId(conv.id)}
                >
                  <div className="flex items-center justify-between gap-2">
                    <p className="text-sm font-medium truncate flex-1">{conv.title}</p>
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        handleDeleteConversation(conv.id);
                      }}
                      className="p-1 hover:bg-destructive/10 rounded transition-colors"
                    >
                      <Trash2 className="w-4 h-4 text-destructive" />
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        </ScrollArea>
      </div>

      {/* Main Chat Area */}
      <div className="flex-1 flex flex-col">
        {/* Header */}
        <div className="border-b border-border bg-card p-4 flex items-center justify-between">
          <button
            onClick={() => setIsSidebarOpen(!isSidebarOpen)}
            className="p-2 hover:bg-muted rounded-lg transition-colors md:hidden"
          >
            <svg
              className="w-6 h-6"
              fill="none"
              stroke="currentColor"
              viewBox="0 0 24 24"
            >
              <path
                strokeLinecap="round"
                strokeLinejoin="round"
                strokeWidth={2}
                d="M4 6h16M4 12h16M4 18h16"
              />
            </svg>
          </button>
          <h1 className="text-xl font-bold text-accent">TheBest IA</h1>
          <a href="/gallery" className="p-2 hover:bg-muted rounded-lg transition-colors">
            <ImageIcon className="w-6 h-6" />
          </a>
        </div>

        {/* Messages */}
        <ScrollArea className="flex-1 p-4 md:p-6">
          <div className="space-y-4 max-w-4xl mx-auto">
            {messages.length === 0 ? (
              <div className="flex flex-col items-center justify-center h-96 text-center">
                <MessageSquare className="w-12 h-12 text-muted-foreground mb-4" />
                <p className="text-muted-foreground">Comece uma conversa para ver as mensagens aqui</p>
              </div>
            ) : (
              messages.map((msg, idx) => {
                const isUser = msg.role === "user";
                const alignClass = isUser ? "justify-end" : "justify-start";
                const bgClass = isUser
                  ? "bg-accent text-accent-foreground rounded-br-none"
                  : "bg-muted text-foreground rounded-bl-none";

                return (
                  <div key={idx} className={`flex ${alignClass}`}>
                    <div className={`max-w-md md:max-w-2xl px-4 py-3 rounded-lg ${bgClass}`}>
                      {msg.role === "assistant" ? (
                        <Streamdown>{msg.content}</Streamdown>
                      ) : (
                        <p className="text-sm">{msg.content}</p>
                      )}
                    </div>
                  </div>
                );
              })
            )}
            {isLoading && (
              <div className="flex justify-start">
                <div className="bg-muted text-foreground px-4 py-3 rounded-lg rounded-bl-none flex items-center gap-2">
                  <Loader2 className="w-4 h-4 animate-spin" />
                  <span className="text-sm">Processando...</span>
                </div>
              </div>
            )}
            <div ref={scrollRef} />
          </div>
        </ScrollArea>

        {/* Input */}
        <div className="border-t border-border bg-card p-4 md:p-6">
          <div className="max-w-4xl mx-auto space-y-3">
            <div className="flex gap-2">
              <form onSubmit={handleSendMessage} className="flex-1 flex gap-2">
            <Input
              value={inputValue}
              onChange={(e) => setInputValue(e.target.value)}
              placeholder="Digite sua mensagem..."
              disabled={isLoading || !currentConversationId}
              className="flex-1"
            />
            <Button
              type="submit"
              disabled={isLoading || !inputValue.trim() || !currentConversationId}
              className="bg-accent hover:bg-accent/90 text-accent-foreground gap-2"
            >
              {isLoading ? (
                <Loader2 className="w-4 h-4 animate-spin" />
              ) : (
                <Send className="w-4 h-4" />
              )}
              <span className="hidden sm:inline">Enviar</span>
            </Button>
              </form>
            </div>
            <div className="flex justify-end">
              <ImageGenerator />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
