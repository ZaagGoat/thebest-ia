import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Loader2, Download, Trash2, ArrowLeft } from "lucide-react";
import { trpc } from "@/lib/trpc";
import { toast } from "sonner";
import { useLocation } from "wouter";
import { useEffect, useState } from "react";

interface GeneratedImage {
  id: number;
  userId: number;
  conversationId?: number | null;
  prompt: string;
  imageUrl: string;
  createdAt: Date | string;
}

export default function ImageGallery() {
  const { isAuthenticated } = useAuth();
  const [, setLocation] = useLocation();
  const [images, setImages] = useState<GeneratedImage[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  const getGeneratedImages = trpc.chat.getGeneratedImages.useQuery(undefined, {
    enabled: isAuthenticated,
  });

  const deleteImageMutation = trpc.chat.deleteGeneratedImage.useMutation();

  useEffect(() => {
    if (getGeneratedImages.data) {
      setImages(getGeneratedImages.data);
      setIsLoading(false);
    }
  }, [getGeneratedImages.data]);

  const handleDeleteImage = async (imageId: number) => {
    try {
      await deleteImageMutation.mutateAsync({ imageId });
      setImages(images.filter((img) => img.id !== imageId));
      toast.success("Imagem deletada com sucesso");
    } catch (error) {
      console.error("Delete error:", error);
      toast.error("Erro ao deletar imagem");
    }
  };

  const handleDownloadImage = (imageUrl: string, prompt: string) => {
    const link = document.createElement("a");
    link.href = imageUrl;
    link.download = `thebest-ia-${Date.now()}.png`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  if (!isAuthenticated) {
    return (
      <div className="flex items-center justify-center h-screen">
        <p className="text-muted-foreground">Por favor, faça login para ver suas imagens</p>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <div className="border-b border-border bg-card">
        <div className="max-w-6xl mx-auto px-4 py-6 flex items-center gap-4">
          <Button
            variant="outline"
            size="sm"
            onClick={() => setLocation("/")}
            className="gap-2"
          >
            <ArrowLeft size={18} />
            Voltar
          </Button>
          <h1 className="text-2xl font-bold">Galeria de Imagens</h1>
        </div>
      </div>

      {/* Content */}
      <div className="max-w-6xl mx-auto px-4 py-8">
        {isLoading ? (
          <div className="flex items-center justify-center h-96">
            <Loader2 className="w-8 h-8 animate-spin text-muted-foreground" />
          </div>
        ) : images.length === 0 ? (
          <div className="flex flex-col items-center justify-center h-96 text-center">
            <p className="text-muted-foreground mb-4">Nenhuma imagem gerada ainda</p>
            <Button onClick={() => setLocation("/chat")} className="gap-2">
              Ir para o Chat
            </Button>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {images.map((image) => (
              <Card key={image.id} className="overflow-hidden hover:shadow-lg transition-shadow">
                <div className="aspect-square overflow-hidden bg-muted">
                  <img
                    src={image.imageUrl}
                    alt={image.prompt}
                    className="w-full h-full object-cover hover:scale-105 transition-transform duration-300"
                  />
                </div>
                <div className="p-4 space-y-3">
                  <div>
                    <p className="text-sm text-muted-foreground mb-1">Prompt:</p>
                    <p className="text-sm font-medium line-clamp-2">{image.prompt}</p>
                  </div>
                  <div>
                    <p className="text-xs text-muted-foreground">
                      {new Date(image.createdAt).toLocaleDateString("pt-BR", {
                        year: "numeric",
                        month: "long",
                        day: "numeric",
                        hour: "2-digit",
                        minute: "2-digit",
                      })}
                    </p>
                  </div>
                  <div className="flex gap-2">
                    <Button
                      onClick={() => handleDownloadImage(image.imageUrl, image.prompt)}
                      variant="outline"
                      size="sm"
                      className="flex-1 gap-2"
                    >
                      <Download size={16} />
                      Baixar
                    </Button>
                    <Button
                      onClick={() => handleDeleteImage(image.id)}
                      variant="destructive"
                      size="sm"
                      className="gap-2"
                      disabled={deleteImageMutation.isPending}
                    >
                      {deleteImageMutation.isPending ? (
                        <Loader2 size={16} className="animate-spin" />
                      ) : (
                        <Trash2 size={16} />
                      )}
                    </Button>
                  </div>
                </div>
              </Card>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
