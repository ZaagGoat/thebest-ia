import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { MessageSquare, Zap, Shield, Sparkles } from "lucide-react";
import { getLoginUrl } from "@/const";
import { useLocation } from "wouter";

export default function Home() {
  const { user, isAuthenticated, logout } = useAuth();
  const [, navigate] = useLocation();

  return (
    <div className="min-h-screen bg-gradient-to-br from-background via-background to-muted">
      {/* Header */}
      <header className="border-b border-border bg-card/50 backdrop-blur">
        <div className="max-w-6xl mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <MessageSquare className="w-8 h-8 text-accent" />
            <h1 className="text-2xl font-bold text-foreground">TheBest IA</h1>
          </div>
          <div className="flex items-center gap-4">
            {isAuthenticated ? (
              <>
                <span className="text-sm text-muted-foreground">Bem-vindo, {user?.name}</span>
                <Button
                  onClick={() => navigate("/chat")}
                  className="bg-accent hover:bg-accent/90 text-accent-foreground"
                >
                  Ir para Chat
                </Button>
                <Button
                  onClick={() => logout()}
                  variant="outline"
                >
                  Sair
                </Button>
              </>
            ) : (
              <a href={getLoginUrl()}>
                <Button className="bg-accent hover:bg-accent/90 text-accent-foreground">
                  Fazer Login
                </Button>
              </a>
            )}
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="max-w-6xl mx-auto px-4 py-20 text-center">
        <div className="mb-8">
          <h2 className="text-5xl md:text-6xl font-bold mb-4 text-foreground">
            Converse com a{" "}
            <span className="text-accent">Melhor IA</span>
          </h2>
          <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
            Uma experiência elegante e intuitiva de chat com inteligência artificial avançada
          </p>
        </div>

        {isAuthenticated ? (
          <Button
            onClick={() => navigate("/chat")}
            size="lg"
            className="bg-accent hover:bg-accent/90 text-accent-foreground text-lg px-8 py-6"
          >
            <Sparkles className="w-5 h-5 mr-2" />
            Começar a Conversar
          </Button>
        ) : (
          <a href={getLoginUrl()}>
            <Button
              size="lg"
              className="bg-accent hover:bg-accent/90 text-accent-foreground text-lg px-8 py-6"
            >
              <Sparkles className="w-5 h-5 mr-2" />
              Começar Agora
            </Button>
          </a>
        )}
      </section>

      {/* Features Section */}
      <section className="max-w-6xl mx-auto px-4 py-16">
        <div className="grid md:grid-cols-3 gap-8">
          <div className="bg-card border border-border rounded-lg p-6 hover:shadow-lg transition-shadow">
            <MessageSquare className="w-12 h-12 text-accent mb-4" />
            <h3 className="text-xl font-bold mb-2 text-foreground">Chat Inteligente</h3>
            <p className="text-muted-foreground">
              Converse naturalmente com uma IA que entende contexto e fornece respostas precisas
            </p>
          </div>

          <div className="bg-card border border-border rounded-lg p-6 hover:shadow-lg transition-shadow">
            <Zap className="w-12 h-12 text-accent mb-4" />
            <h3 className="text-xl font-bold mb-2 text-foreground">Rápido e Eficiente</h3>
            <p className="text-muted-foreground">
              Respostas instantâneas com processamento otimizado e interface responsiva
            </p>
          </div>

          <div className="bg-card border border-border rounded-lg p-6 hover:shadow-lg transition-shadow">
            <Shield className="w-12 h-12 text-accent mb-4" />
            <h3 className="text-xl font-bold mb-2 text-foreground">Seguro e Privado</h3>
            <p className="text-muted-foreground">
              Seus dados são protegidos com autenticação segura e histórico privado
            </p>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t border-border bg-card/50 mt-20">
        <div className="max-w-6xl mx-auto px-4 py-8 text-center text-muted-foreground">
          <p>TheBest IA © 2026. Todos os direitos reservados.</p>
        </div>
      </footer>
    </div>
  );
}
