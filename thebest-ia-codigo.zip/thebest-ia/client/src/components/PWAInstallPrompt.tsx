import { useEffect, useState } from 'react';
import { Button } from '@/components/ui/button';
import { X } from 'lucide-react';
import { usePWA } from '@/_core/hooks/usePWA';

export function PWAInstallPrompt() {
  const { isInstallable, isInstalled, install } = usePWA();
  const [showPrompt, setShowPrompt] = useState(false);

  useEffect(() => {
    if (isInstallable && !isInstalled) {
      setShowPrompt(true);
    }
  }, [isInstallable, isInstalled]);

  if (!showPrompt || isInstalled) {
    return null;
  }

  const handleInstall = async () => {
    try {
      await install();
      setShowPrompt(false);
    } catch (error) {
      console.error('Failed to install app:', error);
    }
  };

  return (
    <div className="fixed bottom-4 left-4 right-4 bg-gradient-to-r from-purple-600 to-purple-700 text-white rounded-lg shadow-lg p-4 flex items-center justify-between gap-4 z-50 max-w-md">
      <div className="flex-1">
        <h3 className="font-semibold text-sm mb-1">Instalar TheBest IA</h3>
        <p className="text-xs opacity-90">Acesse o app diretamente da sua tela inicial</p>
      </div>
      <div className="flex gap-2 flex-shrink-0">
        <Button
          onClick={handleInstall}
          size="sm"
          className="bg-white text-purple-600 hover:bg-gray-100"
        >
          Instalar
        </Button>
        <button
          onClick={() => setShowPrompt(false)}
          className="p-1 hover:bg-purple-500 rounded transition-colors"
        >
          <X size={16} />
        </button>
      </div>
    </div>
  );
}
