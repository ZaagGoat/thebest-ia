import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card } from '@/components/ui/card';
import { Loader2, Image as ImageIcon, Download } from 'lucide-react';
import { trpc } from '@/lib/trpc';
import { toast } from 'sonner';

interface ImageGeneratorProps {
  onImageGenerated?: (imageUrl: string) => void;
}

export function ImageGenerator({ onImageGenerated }: ImageGeneratorProps) {
  const [prompt, setPrompt] = useState('');
  const [isOpen, setIsOpen] = useState(false);
  const generateImageMutation = trpc.chat.generateImage.useMutation();

  const handleGenerateImage = async () => {
    if (!prompt.trim()) {
      toast.error('Por favor, descreva a imagem que deseja gerar');
      return;
    }

    try {
      const result = await generateImageMutation.mutateAsync({ prompt, conversationId: undefined });
      
      if (result.success && result.imageUrl) {
        toast.success('Imagem gerada com sucesso!');
        onImageGenerated?.(result.imageUrl);
        setPrompt('');
        setIsOpen(false);
      } else {
        toast.error(result.error || 'Erro ao gerar imagem');
      }
    } catch (error) {
      console.error('Image generation error:', error);
      toast.error('Erro ao gerar imagem. Tente novamente.');
    }
  };

  const handleDownloadImage = (imageUrl: string) => {
    const link = document.createElement('a');
    link.href = imageUrl;
    link.download = `thebest-ia-${Date.now()}.png`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  if (!isOpen) {
    return (
      <Button
        onClick={() => setIsOpen(true)}
        variant="outline"
        className="gap-2"
      >
        <ImageIcon size={18} />
        Gerar Imagem
      </Button>
    );
  }

  return (
    <Card className="p-4 w-full max-w-md">
      <div className="space-y-4">
        <div>
          <label className="block text-sm font-medium mb-2">
            Descreva a imagem que deseja gerar
          </label>
          <Input
            placeholder="Ex: Um gato futurista em um planeta alienígena..."
            value={prompt}
            onChange={(e) => setPrompt(e.target.value)}
            disabled={generateImageMutation.isPending}
            onKeyPress={(e) => {
              if (e.key === 'Enter' && !generateImageMutation.isPending) {
                handleGenerateImage();
              }
            }}
          />
        </div>

        <div className="flex gap-2">
          <Button
            onClick={handleGenerateImage}
            disabled={generateImageMutation.isPending || !prompt.trim()}
            className="flex-1 gap-2"
          >
            {generateImageMutation.isPending ? (
              <>
                <Loader2 size={18} className="animate-spin" />
                Gerando...
              </>
            ) : (
              <>
                <ImageIcon size={18} />
                Gerar
              </>
            )}
          </Button>
          <Button
            onClick={() => {
              setIsOpen(false);
              setPrompt('');
            }}
            variant="outline"
          >
            Cancelar
          </Button>
        </div>

        {generateImageMutation.data?.success && generateImageMutation.data?.imageUrl && (
          <div className="space-y-2">
            <img
              src={generateImageMutation.data.imageUrl}
              alt={prompt}
              className="w-full rounded-lg border border-border"
            />
            <Button
              onClick={() => handleDownloadImage(generateImageMutation.data!.imageUrl!)}
              variant="outline"
              size="sm"
              className="w-full gap-2"
            >
              <Download size={16} />
              Baixar Imagem
            </Button>
          </div>
        )}
      </div>
    </Card>
  );
}
